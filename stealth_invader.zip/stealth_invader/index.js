/*
=================Discription=================

【効果音について】
効果音については下記の2箇所から使用させていただきました。
なお、効果音ラボ様より使用させていただいた効果音については、演出のために合成処理を施しております。
Alexa Skills Kitサウンドライブラリ : https://developer.amazon.com/ja/docs/custom-skills/ask-soundlibrary.html
効果音ラボ : https://soundeffect-lab.info/

=============================================
*/
'use strict';

//////////////////////////////////////////////////////////////////////////////////////////
// Library variable definition                                                          //
//////////////////////////////////////////////////////////////////////////////////////////

const Alexa = require('ask-sdk');
const Subject = require('./subject');
// 標準のSDKモジュールがインストールされている場合、'ask-sdk' を使用してください

//////////////////////////////////////////////////////////////////////////////////////////
// Constant variable definition                                                         //
//////////////////////////////////////////////////////////////////////////////////////////

const INTERVAL100      = '<break time="100ms"/> '
const INTERVAL200      = '<break time="200ms"/>'
const INTERVAL300      = '<break time="300ms"/>'
const INTERVAL400      = '<break time="400ms"/>'
const INTERVAL500      = '<break time="500ms"/>'
const INTERVAL1000      = '<break time="1000ms"/>'
const INTERVAL2000      = '<break time="2000ms"/>'
const INTERVAL_LONG    = '<break time="3000ms"/>'

//状態遷移のステート
const State = {
    Opening: 1,//      LaunchRequestからの問答
    AskHowTo: 2,//     使い方を知っているか
    Description: 3,//  エネルギー砲の使い方
    WeakerStage1: 4,// 雑魚敵1発目
    WeakerStage2: 5,// 雑魚敵2発目
    WeakerStage3: 6,// 雑魚敵3発目
    BossStage: 7, //   ボスキャラ戦闘
    Ending: 8 //       エンディング
}

//////////////////////////////////////////////////////////////////////////////////////////
// Sound effect variable definition                                                     //
//////////////////////////////////////////////////////////////////////////////////////////

const SE_Alerm1        = "<audio src='soundbank://soundlibrary/scifi/amzn_sfx_scifi_alarm_02'/>"
const SE_Alerm2        = "<audio src='soundbank://soundlibrary/scifi/amzn_sfx_scifi_alarm_05'/>"

const SE_Daidara_voice = "<audio src='soundbank://soundlibrary/scifi/amzn_sfx_scifi_alien_voice_05'/>"
const SE_Gee_voice     = "<audio src='soundbank://soundlibrary/scifi/amzn_sfx_scifi_alien_voice_01'/>"
const SE_Arakune_voice = "<audio src='soundbank://soundlibrary/scifi/amzn_sfx_scifi_alien_voice_02'/>"
const SE_Ghost_voice   = "<audio src='soundbank://soundlibrary/magic/amzn_sfx_ghost_spooky_02'/>"
const SE_Boxer_voice   = "<audio src='soundbank://soundlibrary/scifi/amzn_sfx_scifi_alien_voice_07'/>"

const SE_Damaged       = "<audio src='soundbank://soundlibrary/scifi/amzn_sfx_scifi_incoming_explosion_01'/>"
const SE_Fire          = "<audio src='soundbank://soundlibrary/scifi/amzn_sfx_scifi_engines_on_short_burst_01'/>"
const SE_Hit           = "<audio src='soundbank://soundlibrary/scifi/amzn_sfx_scifi_explosion_01'/>"
const SE_Winner        = "<audio src='soundbank://soundlibrary/battle/amzn_sfx_battle_yells_men_run_01'/>"
const SE_Failed_Bomb   = "<audio src='soundbank://soundlibrary/scifi/amzn_sfx_scifi_missile_02'/>"
const SE_Incoming_Exprosion= "<audio src='soundbank://soundlibrary/scifi/amzn_sfx_scifi_incoming_explosion_01'/>"
const SE_Game_Over = "<audio src='https://stealth-invader.s3-ap-northeast-1.amazonaws.com/gameover.mp3'/>"
const SE_Moving = '<audio src="soundbank://soundlibrary/vehicles/futuristic/futuristic_07"/>'

const Lader_defalut = "<audio src='https://stealth-invader.s3-ap-northeast-1.amazonaws.com/lader_default.mp3'/>";
const Lader_correct = "<audio src='https://stealth-invader.s3-ap-northeast-1.amazonaws.com/lader_correct.mp3'/>";
const Lader_1 = "<audio src='https://stealth-invader.s3-ap-northeast-1.amazonaws.com/lader_1.mp3'/>";
const Lader_2 = "<audio src='https://stealth-invader.s3-ap-northeast-1.amazonaws.com/lader_2.mp3'/>";
const Lader_3 = "<audio src='https://stealth-invader.s3-ap-northeast-1.amazonaws.com/lader_3.mp3'/>";
const Lader_4 = "<audio src='https://stealth-invader.s3-ap-northeast-1.amazonaws.com/lader_4.mp3'/>";
const Lader_5 = "<audio src='https://stealth-invader.s3-ap-northeast-1.amazonaws.com/lader_5.mp3'/>";
const Lader_6 = "<audio src='https://stealth-invader.s3-ap-northeast-1.amazonaws.com/lader_6.mp3'/>";
const Lader_7 = "<audio src='https://stealth-invader.s3-ap-northeast-1.amazonaws.com/lader_7.mp3'/>";
const Lader_8 = "<audio src='https://stealth-invader.s3-ap-northeast-1.amazonaws.com/lader_8.mp3'/>";
const Lader_9 = "<audio src='https://stealth-invader.s3-ap-northeast-1.amazonaws.com/lader_9.mp3'/>";
const Lader_10 = "<audio src='https://stealth-invader.s3-ap-northeast-1.amazonaws.com/lader_10.mp3'/>";
const Lader_11 = "<audio src='https://stealth-invader.s3-ap-northeast-1.amazonaws.com/lader_11.mp3'/>";

//////////////////////////////////////////////////////////////////////////////////////////
// Serif variable definition                                                            //
//////////////////////////////////////////////////////////////////////////////////////////

var openingText = new String();
openingText = 'ステルスインベーダーを起動します' + INTERVAL2000 + SE_Alerm1 + "\
<prosody volume='x-loud'><voice name='Salli'>Alexa!<break time='0.5s'/> emergency!emergency!</voice></prosody>" + INTERVAL2000 + '\
我々の拠点は何者かに攻撃を受けています！' + INTERVAL1000 + '\
インベーダーは高度な技術を持っているようで視認できません。' + INTERVAL1000 + "\
<prosody volume='x-loud'>まさに、絶対絶命！</prosody>" + INTERVAL1000 + '\
レーダー反応を頼りに、高出力エネルギー砲でインベーダーからの侵略を防いでください' + INTERVAL1000 + "\
よろしいですか？";

//説明を聞くかどうかの問いかけ
var yesIntentText = new String();
yesIntentText = "<prosody volume='x-loud'>そうこなくっちゃ！</prosody>" + INTERVAL300 + '\
砲台の使い方は、ご存知ですか？';

var pleaseOderText = new String();
pleaseOderText = "<prosody volume='x-loud'>それでは指揮官</prosody>" + INTERVAL200 +"\
隊員へご指示をお願いします！"

//準備ができていない場合のテキスト_01
var noIntentText01 = new String();
noIntentText01 = SE_Damaged + "\
<prosody pitch='x-high'>キャーーーー</prosody>" + INTERVAL400 + "\
<prosody volume='x-loud'>早く！</prosody>" + INTERVAL200 + "\
<prosody volume='loud'>今、人類を救えるのは</prosody>" + INTERVAL100 +  '\
指揮官であるあなただけです！' + INTERVAL500 + '\
準備はよろしいですか？';

//準備ができていない場合のテキスト_02
var noIntentText02 = new String();
noIntentText02 = SE_Failed_Bomb + "<prosody volume='x-loud'>勇気を出してください</prosody>" + INTERVAL100 + "\
<prosody volume='loud'>今、人類を救えるのは指揮官であるあなただけです！</prosody>" + INTERVAL500 + '\
準備はよろしいですか？?';

//準備ができていない場合のテキスト_03
var noIntentText03 = new String();
noIntentText03 =SE_Alerm2 +  INTERVAL300 + "\
<prosody volume='loud'>このままだと危険です！</prosody>" + "\
<prosody volume='loud'>この拠点は制圧されてしまいます！</prosody>" + INTERVAL500 + '\
準備はよろしいですか？';

//ヒントテキスト
var hintText = new String();
hintText = "私の感によれば、インベーダーの位置は"

var myPositionText = new String();
myPositionText = "現在高出力エネルギー砲が向いている先は"

//敵撃破テキスト
var nInvBreakText = new String();
nInvBreakText = "<say-as interpret-as='interjection'>やったあ</say-as>" + INTERVAL100 + '\
直撃です！インベーダーを撃破しました。'

//敵出現テキスト
var nextEnemyText = new String();
nextEnemyText = "次のインベーダーが来ます。続けて撃墜してください"+INTERVAL200+"なお、砲台の方角は12時へリセットされました。";

var finalEnemyText = new String();
finalEnemyText = "まだまだ来ます！"+INTERVAL200+"砲台の方角は12時へリセットされましたので、お気をつけて" ;

//ボス出現テキスト
var bossCallText = new String();
bossCallText = SE_Alerm2 + "<prosody volume='x-loud'>大変です！</prosody>" + '\
レーダーに特殊な反応が出ています。' + INTERVAL100 + '\
恐らく、インベーダーの親玉だと思われます。' + INTERVAL100 + "\
<prosody volume='loud'>指揮官、ご指示を。</prosody>";
 
//ゲームオーバーテキスト
var failedText = new String();
failedText = SE_Incoming_Exprosion + SE_Game_Over + '<say-as interpret-as="interjection">あ〜あ</say-as>' + INTERVAL300 + '\
やられてしまいましたね。' + INTERVAL400 + '\
ステルスインベーダーの侵略により' + INTERVAL100 + '\
人類は滅亡しました。' + INTERVAL400 + "\
<prosody pitch='x-high'>ちゃんちゃん</prosody>" + INTERVAL400 + '\
遊んでくれて<say-as interpret-as="interjection">ありがとう</say-as>。';

//あそびかたテキスト
var helpText = new String();
helpText ='これから' + INTERVAL100 + '\
ゲームの説明をおこないます。' + INTERVAL300 + '\
まずは、この音を聞いてください' + INTERVAL300 + Lader_defalut + '\
これがインベーダーを唯一認識できるレーダーです。' + INTERVAL300 + '\
2秒感覚で一周します' + INTERVAL200 + `\
インベーダーの反応がある時はこんな音がします。` + INTERVAL400 + Lader_4 + INTERVAL300 + '\
エネルギー砲が向ける方向は' + INTERVAL100 + '\
1時から12時までです。' + INTERVAL300 + '\
方向を変えたい時は、何時の方向へ展開と言ってください。'　+ INTERVAL300 + '\
巨大な砲台なので、方向転換にはそれなりの時間がかかるため、1ターンを消費します。' + INTERVAL300 +'\
発射の合図は。' + INTERVAL200 + "\
<prosody volume='x-loud'>撃て！</prosody>" + INTERVAL200 + '\
と言って攻撃してください。' + INTERVAL200 + '\
射撃には、1ターンを消費します。' + INTERVAL400 + '\
状況はターンによって進行します。' + INTERVAL200 + '\
決まったターンの中でインベーダーを撃破できない場合' + INTERVAL100 + '\
インベーダーからの攻撃を受けて、ゲームが終わってしまいます。' + INTERVAL300 + '\
いよいよ戦闘です。あなたの予測する力と、指揮の力で、地球を救ってください。' + '\
準備はよろしいですか？';

//ゲームクリア用テキスト
var gameBeatText = new String();
gameBeatText = INTERVAL200 + '\
あなたのおかげで地球は救われました。' + INTERVAL300 + '\
しかし、まだ地球を狙っているインベーダーは存在します。' + `\
あなたの力はまだ必要とされています。` + INTERVAL300 + '\
それでは。' + INTERVAL200 + "<prosody volume='x-loud'>敬礼！</prosody>"+ '\
遊んでくれて<say-as interpret-as="interjection">ありがとう</say-as>。';

//////////////////////////////////////////////////////////////////////////////////////////
// Fluctuating game variable definition                                                 //
//////////////////////////////////////////////////////////////////////////////////////////
// 最初の問答カウント
var introCount = 0;
// 現在の砲台の向き
var myPosition = 12;
// 敵の位置
var enemyPosition = 12;
// ターン数
var turn = 1;
// 最終的な音声
var outputLader = "";
// 敵破壊可能か
var hitableStatus = false;

//////////////////////////////////////////////////////////////////////////////////////////
// Invader information variable definition                                              //
//////////////////////////////////////////////////////////////////////////////////////////

// 敵の名前
var invaderName = "ウィーカー";
// 敵の行動パターン
var enemyMovement = [0,0,0,0,0];
// 敵の動くスピード
var enemySpeed = 1;
// ターン制限
var LimitTurn = 5;
// 敵の声
var enemyVoice = "";

//////////////////////////////////////////////////////////////////////////////////////////
// Created functions                                                                    //
//////////////////////////////////////////////////////////////////////////////////////////

function changeState(handlerInput, stateInfo) {
    // セッション情報の取得
    let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
    sessionAttributes.state = stateInfo

    // セッション情報の保存
    handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
    return sessionAttributes.state;
}

function readCurrentState(handlerInput) {
    let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
    // 初期化
    if (!sessionAttributes.state) {
        sessionAttributes.state = State.waiting
        // セッション情報の保存
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
    }
    return sessionAttributes.state;
}

function countIntroTalk(){
    console.log("countIntroTalk");
    console.log("introCount is"+introCount);
    introCount++;
    if(introCount == 1){
        return noIntentText01;
    }else if(introCount == 2){
        return noIntentText02;
    }else if(introCount == 3){
        return noIntentText03;
    }else{
        return "end";
    }
}

function selectEnemy(handlerInput) {
    // 雑魚敵なのかボスなのか、またボスならどのボスなのかランダムに選出する関数を作る
    console.log("selectEnemy called");
    var enemyId = "";
    if(readCurrentState(handlerInput) == State.BossStage){
        enemyId = randam(6,2);
    }else{
        enemyId = 1
    }
    // 情報をリセット
    myPosition = 12;
    enemyPosition = 12;
    turn = 1;
    hitableStatus = false;

    // 敵情報のデータをセット
    var enemyData = Subject.enemy[enemyId-1];
    console.log("enemyData = "+enemyData);
    invaderName = enemyData[0];
    enemyPosition = randam(12,1);
    enemyMovement = enemyData[1];
    enemySpeed = enemyData[2];
    LimitTurn = enemyData[3];
    // もし、ボスだった場合敵の声を選定
    switch (invaderName) {
        case "ジー":
            enemyVoice = SE_Gee_voice;
            break;
        case "アラクネ":
            enemyVoice = SE_Arakune_voice;
            break;
        case "ダイダラ":
            enemyVoice = SE_Daidara_voice;
            break;
        case "ボクサー":
            enemyVoice = SE_Boxer_voice;
            break;
        case "ゴースト":
            enemyVoice = SE_Ghost_voice;
            break;
        default:
            enemyVoice = SE_Ghost_voice;   
            break;
    }
    // 1ターン目の計算
    checkLocationStatus();
}

function enemyMovePattern(enemySpeed){
    var movePoint = 0;
    if(enemySpeed == 1){
        // 鈍足設定
        if(turn % 3 == 0){
            // 行動する
            if(enemyMovement.length != 0){
                if(enemyMovement[0] == 0){
                    movePoint = randam(11,1);
                }else{
                    movePoint = enemyMovement[0];
                    enemyMovement.shift(); 
                }
            }
        }
    }else if(enemySpeed == 2){
        // 通常設定
        if(turn % 2 == 0){
            if(enemyMovement.length != 0){
                if(enemyMovement[0] == 0){
                    movePoint = randam(11,1);
                }else{
                    movePoint = enemyMovement[0];
                    enemyMovement.shift(); 
                }
            }
        }
    }else if(enemySpeed == 3){
        // ランダム設定
        var randamResult = 1;
        randamResult = randam(2,1);
        if(randamResult == 2){
            // 行動する
            if(enemyMovement.length != 0){
                if(enemyMovement[0] == 0){
                    movePoint = randam(11,1);
                }else{
                    movePoint = enemyMovement[0];
                    enemyMovement.shift(); 
                }
            }
        }else{
            console.log("The invader is listening to you")
        }
    }else{
        // 例外なので鈍足
        if(turn % 3 == 0){
            // 行動する
            if(enemyMovement.length != 0){
                if(enemyMovement[0] == 0){
                    movePoint = randam(11,1);
                }else{
                    movePoint = enemyMovement[0];
                    enemyMovement.shift(); 
                }
            }
        }
    }
    movePoint = enemyPosition+movePoint;
    // movePointが12以上だった場合12引く
    if(movePoint > 12){
        movePoint = movePoint - 12;
    }
    enemyPosition = movePoint;
}

function checkLocationStatus(){
    // 自分の向いている方向と敵が向いている方向を算出し、答え合わせをする関数を作る
    console.log("checkLocationStatus called");
    var positionCheck = 12 - myPosition + enemyPosition;
    if(positionCheck > 12){
        positionCheck = positionCheck - 12
    }
    console.log("ロケーションチェック");
    console.log(myPosition);
    console.log(enemyPosition);
    console.log(positionCheck);
    // 発射出来るかの計算 + 次のレーダーの音声を選択
    switch (positionCheck) {
        case 1:
            hitableStatus = false;
            outputLader = Lader_1;
            break;
        case 2:
                hitableStatus = false;
                outputLader = Lader_2;
            break;
        case 3:
                hitableStatus = false;
                outputLader = Lader_3;
            break;
        case 4:
                hitableStatus = false;
                outputLader = Lader_4;
            break;
        case 5:
                hitableStatus = false;
                outputLader = Lader_5;
            break;
        case 6:
                hitableStatus = false;
                outputLader = Lader_6;
            break;
        case 7:
                hitableStatus = false;
                outputLader = Lader_7;
            break;
        case 8:
                hitableStatus = false;
                outputLader = Lader_8;
            break;
        case 9:
                hitableStatus = false;
                outputLader = Lader_9;
            break;
        case 10:
                hitableStatus = false;
                outputLader = Lader_10;
            break;
        case 11:
                hitableStatus = false;
                outputLader = Lader_11;
            break;
        case 12:
                hitableStatus = true;
                outputLader = Lader_correct;
            break;
    }

}
// ランダムな整数はここでまとめて計算する
function randam(max, min) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min;
}

//////////////////////////////////////////////////////////////////////////////////////////
// Handler functions                                                                    //
//////////////////////////////////////////////////////////////////////////////////////////

//Launchリクエストハンドラー
const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'LaunchRequest';
    },
    async handle(handlerInput) {
        changeState(handlerInput,State.Opening);
        console.log("LaunchRequest is called");
        var speechText = new String();
        speechText += openingText;

        var repromptText = new String();
        //8秒放置した場合に流すテキスト
        repromptText = SE_Failed_Bomb + INTERVAL200 + '\
        時間がありません！早く決断を。';

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(repromptText)
            .getResponse();
    }
};

const YesIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'YesIntent'
    },
    handle(handlerInput) {
        console.log("YesIntent is called")
        var speechText = new String();
        var repromptText = new String();

        switch (readCurrentState(handlerInput)) {
            case State.Opening:// introの問答
                changeState(handlerInput,State.AskHowTo);
                selectEnemy(handlerInput);
                speechText = yesIntentText
                repromptText = '砲台の使い方は、ご存知ですか？';
                break;
            case State.AskHowTo:// 使い方はわかるかへの回答
                changeState(handlerInput,State.WeakerStage1);
                speechText = pleaseOderText+outputLader
                repromptText = '方向、もしくは射撃のご指示をお願いします！'+outputLader;
                break;
            case State.Description:// Helpの説明に理解できたかへの回答
                changeState(handlerInput,State.WeakerStage1);
                speechText = pleaseOderText+outputLader
                repromptText = '方向、もしくは射撃のご指示をお願いします！'+outputLader;
                break;
            default:
                    speechText = "何を言っているんですか?"
                    speechText += INTERVAL200
                    speechText += "さぁ、インベーダーの攻撃が来る前に早くご指示を！"+outputLader;
                    repromptText = '方向、もしくは射撃のご指示をお願いします！'+outputLader;
                break;
        }

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(repromptText)
            .getResponse();
    }
}

const NoIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'NoIntent'
    },
    handle(handlerInput) {
        var speechText = new String();
        var repromptText = new String();

        switch (readCurrentState(handlerInput)) {
            case State.Opening:// introの問答
                speechText = countIntroTalk()
                if(speechText == "end"){
                    return handlerInput.responseBuilder
                        .speak(failedText)
                        .withShouldEndSession(true)
                        .getResponse();
                }
                repromptText = 'どうですか？指揮官をやってみませんか？';
                break;
            case State.AskHowTo:// 使い方はわかるかへの回答
                changeState(handlerInput,State.Description);
                speechText = helpText;
                repromptText = '私の説明、理解できましたかね？';
                break;
            case State.Description: // Helpの説明に理解できたかへの回答
                speechText = helpText;
                speechText += INTERVAL200
                speechText += "まぁ"+INTERVAL100+"習うより慣れろ"+INTERVAL100+"ですよ"
                speechText += INTERVAL200
                speechText += "指揮官になってもらえませんか？"
            default:
                speechText = "何を言っているんですか?"
                speechText += INTERVAL200
                speechText += "さぁ、インベーダーの攻撃が来る前に早くご指示を！"+outputLader
                repromptText = '方向、もしくは射撃のご指示をお願いします！';+outputLader
        }

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(repromptText)
            .getResponse();
    }
}

const MoveIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'MoveIntent'
    },
    handle(handlerInput) {
        console.log("Move is called")
        // スロットのデータを取得
        var intent = handlerInput.requestEnvelope.request.intent;
        var direction = intent.slots.Direction.value;
        if(turn == LimitTurn){
            return handlerInput.responseBuilder
                .speak(failedText)
                .withShouldEndSession(true)
                .getResponse();
        }else{
            // ターン経過+敵の移動
            turn++;
            enemyMovePattern(enemySpeed);
            // 位置情報の再取得
            if(Number(direction.slice(0,2))){
                myPosition=Number(direction.slice(0,2));
            }else{
                myPosition = Number(direction.slice(0,1));
            }
            checkLocationStatus();
            var speechText = new String();
            speechText = direction+"のほうこうへ、展開！"+SE_Moving+INTERVAL200+outputLader;

            var repromptText = new String();
            repromptText = '方向、もしくは射撃のご指示をお願いします！'+outputLader;

            return handlerInput.responseBuilder
                .speak(speechText)
                .reprompt(repromptText)
                .getResponse();
        }
    }
}

const FireIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'FireIntent'
    },
    handle(handlerInput) {
        console.log("Fire is called")
        // ターン追加+敵の移動
        turn++;
        enemyMovePattern(enemySpeed);
        checkLocationStatus();
        // 当たり判定
        var resultText = new String();
        if(hitableStatus){
            resultText = SE_Hit+nInvBreakText
            // 撃破したので次のステージへ
            switch (readCurrentState(handlerInput)) {
                case State.WeakerStage1:
                    changeState(handlerInput,State.WeakerStage2);
                    selectEnemy(handlerInput);
                    resultText += nextEnemyText+outputLader
                    break;
                case State.WeakerStage2:
                    changeState(handlerInput,State.WeakerStage3);
                    selectEnemy(handlerInput);
                    resultText += finalEnemyText+outputLader
                    break;
                case State.WeakerStage3:
                    changeState(handlerInput,State.BossStage);
                    selectEnemy(handlerInput);
                    resultText += enemyVoice+bossCallText+outputLader;
                    break;
                case State.BossStage:
                    var clearText = new String();
                    clearText = "高出力エネルギー砲を最大出力に！"+INTERVAL200 + "\
                    <prosody volume='x-loud'>打て！</prosody>"+SE_Fire+'\
                    インベーダーの反応が消えました。我々の勝利です' + SE_Winner + '\
                    インベーダーのタイプは' + invaderName + 'だったようですね。' + gameBeatText
                    return handlerInput.responseBuilder
                        .speak(clearText)
                        .withShouldEndSession(true)
                        .getResponse();
                default:
                    //異常ケースの場合、stage2へ戻る
                    changeState(handlerInput,State.WeakerStage2);
                    selectEnemy(handlerInput);
                    resultText += nextEnemyText
                    break;
            }
        }else{
            if(turn == LimitTurn){
                return handlerInput.responseBuilder
                    .speak(failedText)
                    .withShouldEndSession(true)
                    .getResponse();
            }else{
                resultText = INTERVAL100+"残念、外れてしまったみたいです。"+INTERVAL100+"次のご指示をお願いします！"+outputLader
            }
        }

        var speechText = new String();
        speechText = "高出力エネルギー砲、<prosody volume='x-loud'>打て！</prosody>"+SE_Fire+resultText

        var repromptText = new String();
        repromptText = '指揮官、次のご指示をお願いします！'+outputLader;

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(repromptText)
            .getResponse();
    }
}

//Hint
const HintIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'HintIntent';
    },
    handle(handlerInput) {
        var speechText = new String();
        var repromptText = new String();
        switch (readCurrentState(handlerInput)) {
            case State.WeakerStage1:// 戦闘中のみ発動
            case State.WeakerStage2:
            case State.WeakerStage3:
            case State.BossStage:
                // ターン追加+敵の移動
                turn++;
                enemyMovePattern(enemySpeed);
                checkLocationStatus();
                if(turn == LimitTurn){
                    return handlerInput.responseBuilder
                        .speak(failedText)
                        .withShouldEndSession(true)
                        .getResponse();
                }else{
                    speechText = hintText+INTERVAL300+enemyPosition+"時の方向にいます。"+outputLader;
                    repromptText = '指揮官、次のご指示をお願いします！'+outputLader;
                    return handlerInput.responseBuilder
                        .speak(speechText)
                        .reprompt(repromptText)
                        .getResponse();
                }
                break;
            default:
                    speechText = "すみません、よくわからなかったです"+INTERVAL100+"続けますが、よろしいですか？"
                    repromptText = '続けますが、よろしいですか？';
                    return handlerInput.responseBuilder
                        .speak(speechText)
                        .reprompt(repromptText)
                        .getResponse();
                break;
        }
    }
};

//MyPosition
const MyPositionIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'MyPositionIntent';
    },
    handle(handlerInput) {
        var speechText = new String();
        var repromptText = new String();
        switch (readCurrentState(handlerInput)) {
            case State.WeakerStage1:// 戦闘中のみ発動
            case State.WeakerStage2:
            case State.WeakerStage3:
            case State.BossStage:
                // ターン追加+敵の移動
                turn++;
                enemyMovePattern(enemySpeed);
                checkLocationStatus();
                if(turn == LimitTurn){
                    return handlerInput.responseBuilder
                        .speak(failedText)
                        .withShouldEndSession(true)
                        .getResponse();
                }else{
                    speechText = myPositionText+INTERVAL300+myPosition+"時の方向です。"+outputLader;
                    repromptText = '指揮官、次のご指示をお願いします！'+outputLader;
                    return handlerInput.responseBuilder
                        .speak(speechText)
                        .reprompt(repromptText)
                        .getResponse();
                }
                break;
            default:
                    speechText = "すみません、よくわからなかったです"+INTERVAL100+"続けますが、よろしいですか？"
                    repromptText = '続けますが、よろしいですか？';
                    return handlerInput.responseBuilder
                        .speak(speechText)
                        .reprompt(repromptText)
                        .getResponse();
                break;
        }
    }
};

//Help
const HelpIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        changeState(handlerInput,State.Description);
        var speechText = new String();
        speechText = helpText;

        var repromptText = new String();
        repromptText = '私の説明、理解できましたかね？';

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(repromptText)
            .getResponse();
    }
};

//Cancel and stop Handler
const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent'
                || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        var speechText = failedText;
        changeState(handlerInput,State.selectGesturePlayer)
        return handlerInput.responseBuilder
            .speak(speechText)
            .withShouldEndSession(true)
            .getResponse();
    }
};

//セッションエンドリクエスト("終了して")って話をした時の動作
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        //クリーンアップロジックをここに追加
        changeState(handlerInput, State.Opening)
        return handlerInput.responseBuilder
            .withShouldEndSession(true)
            .getResponse();
    }
};

//エラーハンドラー
const ErrorHandler = {
    canHandle() {
        console.log('called ErrorHandler.canHandle');
        return true;
    },
    handle(handlerInput, error) {
        console.log(`~~~~ Error handled: ${error.message}`);
        console.log("handler result : %s", readCurrentState(handlerInput));

        var speechText = new String();
        var repromptText = new String();
        speechText += "聞き取る事ができませんでした。もう一度、お願いします";
        repromptText += "指揮官、お早く！インベーダーが攻め入ってきます！";
        
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(repromptText)
            .withShouldEndSession(false)
            .getResponse();
    },
};


/*
前処理の作成
スキルを起動した時、指示を出した時、あらゆる処理をするその前に、共通的に行う処理を定義できる。
*/
const RequestInterceptor = {
    process(handlerInput) {
        return new Promise((resolve, reject) => {
            console.log('called RequestInterceptor');
            console.log(JSON.stringify(handlerInput));

            resolve();
        });
    }
};

/*
後処理の作成
あらゆる処理をした後に共通的に行う処理を定義できる。
*/

const ResponseInterceptor = {
    process(handlerInput) {
        return new Promise((resolve, reject) => {
            console.log('called ResponseInterceptor');
            console.log(JSON.stringify(handlerInput));

            resolve();

        });
    }
};


exports.handler = Alexa.SkillBuilders.standard()
    .addRequestHandlers(LaunchRequestHandler,
        HelpIntentHandler,
        YesIntentHandler,
        NoIntentHandler,
        FireIntentHandler,
        MoveIntentHandler,
        HintIntentHandler,
        MyPositionIntentHandler,
        CancelAndStopIntentHandler,
        SessionEndedRequestHandler)
    .addRequestInterceptors(RequestInterceptor)
    .addResponseInterceptors(ResponseInterceptor)
    .addErrorHandlers(ErrorHandler)
    .lambda();